// Généré par scripts/package-extension.mjs — ne pas modifier à la main.
export const SUPABASE_URL = 'https://kgrkujedgqsmdlltzyzs.supabase.co'
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtncmt1amVkZ3FzbWRsbHR6eXpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMyMjAwMzUsImV4cCI6MjEwODc5NjAzNX0.UgH9RrJgqRTRMKqy4cqPqzfPC0vkxLLtHz-w0oGvYIQ'
